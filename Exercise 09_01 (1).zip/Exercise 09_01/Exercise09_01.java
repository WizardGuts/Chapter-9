import java.util.Scanner;
import java.awt.*;

public class Exercise09_01 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		Rectangle rectangle1 = new Rectangle(40, 4);
		
		Rectangle rectangle2 = new Rectangle(35.9, 3.5);
		
		System.out.println("\n Rectangle 1" + rectangle1);
		System.out.println("Rectangle width: " + rectangle1.width);
		System.out.println("Rectangle height: " + rectangle1.height);
		System.out.println("Rectangle area: " + rectangle1.getArea());
		System.out.println("Rectangle perimeter: " + rectangle1.getPerimeter());
		
		System.out.println("\n Rectangle 2" + rectangle2);
		System.out.println("Rectangle width: " + rectangle2.width);
		System.out.println("Rectangle height: " + rectangle2.height);
		System.out.println("Rectangle area: " + rectangle2.getArea());
		System.out.println("Rectangle perimeter: " + rectangle2.getPerimeter());
	}
}
import java.sql.*;
import java.util.Date;

public class Account {

	private int id;
	private double balance;
	private static double annualInterestRate;
	private java.util.Date dateCreated;
	
	Account() {
		int id = 0;
		double balance = 0;
		double annualInterestRate = 0;
		dateCreated = new java.util.Date();
	}
	
	Account(int newId, double newBalance, double newAnnualInterestRate, Date newDateCreated) {
		id = newId;
		balance = newBalance;
		dateCreated = new java.util.Date();
	}
	
	public void setId(int newId) {
		id = newId;
	}
		
	public void setBalance(double newBalance) {
		balance = newBalance;
	}
	
	public void setAnnualInterestRate(double newAnnualInterestRate) {
		annualInterestRate = newAnnualInterestRate;
	}
	
	public int getId() {
		return id;
	}
	
	public double getBalance() {
		return balance;
	}
	
	public double getAnnualInterestRate() {
		return annualInterestRate;
	}
	
	public java.util.Date getDateCreated() {
		return dateCreated;
	}
	
	public double getMonthlyInterest() {
		return annualInterestRate / 12;
	}
	
	public double getMonthlyInterestRate() {
		return balance * (getMonthlyInterest() / 100);
	}
	
	public double withdraw(double ammount) {
		return balance -= ammount;
	}
	
	public double deposit(double ammount) {
		return balance += ammount;
	}
}
import java.util.Scanner;
import java.util.Date;

public class Exercise09_07 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		Account account = new Account();
		
		account.setId(1122);
		account.setBalance(20000);
		account.setAnnualInterestRate(4.5);
		account.withdraw(2500);
		account.deposit(3000);
		
		System.out.println("Account Statement");
		System.out.println("Account ID: " + account.getId());
		System.out.println("Date created: " + account.getDateCreated());
		System.out.printf("Balance: $%.2f", account.getBalance());
		System.out.printf("\nMonthly Interest: $%.2f", account.getMonthlyInterest());
	}
}